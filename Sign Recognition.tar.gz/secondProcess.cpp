
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>
using namespace std;
int thresh = 100;
int max_thresh = 255;
RNG rng(12345);
void CleanUpROI(Mat & src_){
    cvtColor(src_, src_, CV_BGR2HLS);
    for (int row=0;row<src_.rows;row++){
        for (int col=0;col<src_.cols;col++){
            uchar H = src_.at<Vec3b>(row,col)[0];
            uchar L = src_.at<Vec3b>(row,col)[1];
            uchar S = src_.at<Vec3b>(row,col)[2];
//                         double LS_ratio = ((double) L) / ((double) S);
//                         bool skin_pixel = (S >= 50) && (LS_ratio > 0.5) && (LS_ratio < 3.0) && ((H <= 14) || (H >= 165));
//                         if (!skin_pixel){
//                             imageROI.at<Vec3b>(row,col)[0]=0;
//                             imageROI.at<Vec3b>(row,col)[1]=0;
//                             imageROI.at<Vec3b>(row,col)[2]=0;
//                         }
        }}
    cvtColor(src_, src_, CV_HLS2BGR);

}
void MainWindow::selectROI(Mat & src_,Mat & dst_,int thickness,bool rect){
    Mat bw1;
    vector<vector<Point> > contours1;
    vector<Vec4i> hierarchy1;

    /// Detect edges using Threshold
    cv::Canny(src_, bw1, 0, 10, 5);



    /// Find contours
    findContours( bw1, contours1, hierarchy1, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );


//    cv::findContours( src_, contours, hierarchy, CV_RETR_TREE, CV_CHAIN_APPROX_SIMPLE, Point(0, 0) );


    /// Find the rotated rectangles and ellipses for each contour
    vector<Rect> minRect( contours1.size() );
    vector<RotatedRect> minEllipse( contours1.size() );

    for( int i = 0; i < contours1.size(); i++ ){
        //check size of min area rect for contours
        int b=(minAreaRect( Mat(contours1[i]) ).size.area());
        if ( b > minA && b < maxA ){
            if (rect){ minRect[i] = boundingRect( Mat(contours1[i]) );}
             if( contours1[i].size() > 5 )
               { minEllipse[i] = fitEllipse( Mat(contours1[i]) ); }
       }}
    /// Draw contours + rotated rects + ellipses
//    namedWindow("region",2);
    for( int i = 0; i< contours1.size(); i++ )
       {
        int a=(minAreaRect( Mat(contours1[i]) ).size.area());
        if ( a > minA && a < maxA ){
             Scalar color = Scalar( 255, 255, 255 );
             // contour
             drawContours( dst_, contours1, i, color, 5, 8, vector<Vec4i>(), 0, Point() );
             // ellipse
             if (!rect){
                ellipse( cnt_img, minEllipse[i], color, thickness, 8 );}
             if (rect){
                 RotatedRect re= RotatedRect(minEllipse[i].center,Size2f(minEllipse[i].size.width*1.2,minEllipse[i].size.height*1.2),minEllipse[i].angle);
                ellipse( dst_, re, color, thickness, 8 );}
             // rotated rectangle
             if (rect){
                 rectangle( dst_, minRect[i].tl(), minRect[i].br(), color, 2, 8, 0 );
                //get ROI, test ROI, printout Class



                 Mat imageROI= (SrcRoi(minRect[i])).clone();
                 cv::Size size(30,30);
                 cv::resize(imageROI,imageROI,size,0,0,INTER_AREA);
                 CleanUpROI(imageROI);

//                 imshow("region",imageROI);
//                 Mat  img_mat3 = Mat(1,2700,CV_32FC1);
//                 string path_ ="/home/craig/scripts/temp/0 fuck.jpg";
//                 trainer.getFeatureRow(path_,img_mat3,0);
///_____________________________________________________________________________PREDICTIONS WITH SVM_______________________________
//                 Mat img_mat4 =Mat(1,2700,CV_32FC1);
////                 Mat tester=imread("/home/craig/scripts/training/110/1.jpg");
//                 trainer.makeFeatureRow(imageROI,img_mat4);

////                 trainer.io.print_out_Mat(img_mat3);
//                 cout<<"\n  ______ \n "<<endl;
////                 trainer.io.print_out_Mat(img_mat4);

//                 float answer1= svm.predict(img_mat4);
//                 cout<<answer1<<endl;

//                 imwrite("/home/craig/scripts/all/"+std::to_string(name)+".jpg",imageROI);
//                 name+=1;
//                 waitKey(100);
             }

//             Point2f rect_points[4]; minRect[i].points( rect_points );
//             for( int j = 0; j < 4; j++ )
//                line( dst_, rect_points[j], rect_points[(j+1)%4], color, 1, 8 );}
       }}


}
